Creates a DEB package that will install a script or single-file compiled application to the /home/CURRENTUSER/bin directory.

